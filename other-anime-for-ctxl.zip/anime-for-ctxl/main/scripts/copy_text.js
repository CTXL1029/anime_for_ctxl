function copyText_1()
{   /* Copy text into clipboard */
    const name_1 = "Nhật ký sống chậm nơi dị giới - Nuôi con trong lúc làm mạo hiểm giả";
    navigator.clipboard.writeText(name_1); 
    alert("Đã sao chép tên bộ Anime:\n"+ name_1); 
}

function copyText_2()
{   /* Copy text into clipboard */
    const name_2 = "Mayonaka Punch";
    navigator.clipboard.writeText(name_2);
    alert("Đã sao chép tên bộ Anime:\n"+ name_2); 
}

function copyText_3()
{   /* Copy text into clipboard */
    const name_3 = "Arya Bàn Bên Thỉnh Thoảng Lại Trêu Ghẹo Tôi Bằng Tiếng Nga";
    navigator.clipboard.writeText(name_3);
    alert("Đã sao chép tên bộ Anime:\n"+ name_3); 
}

function copyText_4()
{/* Copy text into clipboard */
    const name_4 = "[Oshi no Ko] 2nd Seasons";
    navigator.clipboard.writeText(name_4);
    alert("Đã sao chép tên bộ Anime:\n"+ name_4); 
}

function copyText_5()
{/* Copy text into clipboard */
    const name_5 = "Koi wa Futago de Warikirenai";
    navigator.clipboard.writeText(name_5);
    alert("Đã sao chép tên bộ Anime:\n"+ name_5); 
}

function copyText_6()
{/* Copy text into clipboard */
    const name_6 = "Shikanoko Nokonoko Koshitantan";
    navigator.clipboard.writeText(name_6);
    alert("Đã sao chép tên bộ Anime:\n"+ name_6); 
}

function copyText_7()
{/* Copy text into clipboard */
    const name_7 = "Hậu Cung Giả Tạo";
    navigator.clipboard.writeText(name_7);
    alert("Đã sao chép tên bộ Anime:\n"+ name_7); 
}